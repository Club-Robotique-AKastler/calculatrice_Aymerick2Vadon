import main.py.py

def division(a,b):
    if a==0 or b==0:
        print("il faut choisir un nombre différent de 0")
    else:
        print(a,"/",b)
    return(a/b)