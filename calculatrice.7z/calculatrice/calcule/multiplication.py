import main.py.py
def multiplication(a,b):
    print(a,"*",b)
    return(a*b)