def soustraction(a,b):
    print(a+b)
    return(a+b)