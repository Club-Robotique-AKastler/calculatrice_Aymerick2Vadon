import addition.py
import soustraction.py
import multiplication.py
import division

print ("Bonjour, si vous voulez additionner taper 1, si vous voulez soustraire taper 2, si vous voulez multiplier taper 3,  si vous voulez diviser taper 4")
c=input()

if c==1:
    a=input()
    b=input()
    addition()
elif c==2:
    a=input()
    b=input()
    soustraction()
elif c==3:
    a=input()
    b=input()
    multiplication()
elif c==4:
    a=input()
    b=input()
    division()
else:
    print("Stp, entre 1,2,3 ou 4")
return()